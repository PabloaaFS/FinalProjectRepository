package com.pf.fsgestion.service;

import com.pf.fsgestion.entity.Proyecto;
import com.pf.fsgestion.repository.ProyectoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

/**
 * Servicio para realizar operaciones relacionadas con la entidad Proyecto.
 */
@Service
public class ProyectoService {

    @Autowired
    private ProyectoRepository proyectoRepository;

    /**
     * Obtiene todos los proyectos.
     *
     * @return Lista de todos los proyectos
     */
    public List<Proyecto> obtenerTodosLosProyectos() {
        return proyectoRepository.findAll();
    }

    /**
     * Valida los datos de un proyecto.
     *
     * @param proyecto El proyecto a validar
     * @return true si los datos son válidos, false de lo contrario
     */
    public boolean validarProyecto(Proyecto proyecto) {
        return proyecto != null &&
                proyecto.getDescripcion() != null &&
                proyecto.getFechaInicio() != null &&
                proyecto.getFechaFin() != null &&
                proyecto.getLugar() != null &&
                proyecto.getObservaciones() != null;
    }

    /**
     * Guarda un nuevo proyecto en la base de datos.
     *
     * @param proyecto El proyecto a guardar
     * @return El proyecto guardado
     * @throws IllegalArgumentException Si los datos del proyecto no son válidos
     */
    public Proyecto guardarProyecto(Proyecto proyecto) {
        if (validarProyecto(proyecto)) {
            return proyectoRepository.save(proyecto);
        } else {
            throw new IllegalArgumentException("Los datos del proyecto no son válidos");
        }
    }

    /**
     * Elimina un proyecto de la base de datos.
     *
     * @param proyectoId El ID del proyecto a eliminar
     * @return true si la operación fue exitosa, false de lo contrario
     */
    public boolean eliminarProyecto(int proyectoId) {
        Proyecto proyecto = proyectoRepository.findById(proyectoId).orElse(null);
        if (proyecto == null) {
            // Proyecto no encontrado
            return false;
        }
        // Actualizar la fecha de baja del proyecto
        proyecto.setFechaBaja(LocalDate.now());
        proyectoRepository.save(proyecto);
        return true;
    }
}
