package com.pf.fsgestion.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Clase de configuración para manejar la política de CORS (Cross-Origin Resource Sharing).
 * CORS permite que un servidor indique en sus respuestas si permite que una página web acceda a los recursos.
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    /**
     * Configura las políticas CORS para permitir peticiones desde un origen específico.
     * @param registry el registro de políticas CORS
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // Mapea todas las URL
                .allowedOrigins("http://localhost:8080") // Permite peticiones desde el origen especificado
                .allowedMethods("GET", "POST", "PUT", "DELETE") // Permite los métodos HTTP especificados
                .allowedHeaders("*") // Permite todos los encabezados en las peticiones
                .allowCredentials(true); // Permite el envío de cookies de autenticación
    }
}


