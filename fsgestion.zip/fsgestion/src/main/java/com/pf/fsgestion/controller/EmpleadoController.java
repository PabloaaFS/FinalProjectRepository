package com.pf.fsgestion.controller;

import com.pf.fsgestion.entity.Empleado;
import com.pf.fsgestion.repository.EmpleadoRepository;
import com.pf.fsgestion.service.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador para manejar las operaciones relacionadas con los empleados.
 */
@RestController
@RequestMapping("/empleados")
public class EmpleadoController {

    @Autowired
    private EmpleadoService empleadoService;

    /**
     * Obtiene una lista de todos los empleados activos.
     * @return lista de empleados activos
     */
    @GetMapping("/activos")
    public List<Empleado> obtenerEmpleadosActivos() {
        return empleadoService.obtenerEmpleadosActivos();
    }

    /**
     * Maneja la solicitud de alta de un nuevo empleado.
     * @param empleado el objeto Empleado que se va a dar de alta
     * @return ResponseEntity con el resultado de la operación
     */
    @PostMapping("/alta")
    public ResponseEntity<?> altaEmpleado(@RequestBody Empleado empleado) {
        try {
            if (!empleadoService.validarEmpleado(empleado)) {
                return ResponseEntity.badRequest().body("Los datos del empleado son inválidos");
            }

            Empleado nuevoEmpleado = empleadoService.guardarEmpleado(empleado);
            return ResponseEntity.ok(nuevoEmpleado);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    /**
     * Maneja la solicitud de dar de baja a un empleado por su ID.
     * @param empleadoId el ID del empleado a dar de baja
     * @return ResponseEntity con el resultado de la operación
     */
    @DeleteMapping("/baja/{id}")
    public ResponseEntity<?> darDeBajaEmpleado(@PathVariable("id") int empleadoId) {
        boolean bajaExitosa = empleadoService.darDeBajaEmpleado(empleadoId);
        if (bajaExitosa) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
