package com.pf.fsgestion.service;

import java.time.LocalDate;
import java.util.List;
import java.util.regex.Pattern;

import com.pf.fsgestion.entity.Empleado;
import com.pf.fsgestion.repository.EmpleadoRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

/**
 * Servicio para realizar operaciones relacionadas con la entidad Empleado.
 */
@Service
public class EmpleadoService {

    @Autowired
    private EmpleadoRepository empleadoRepository;

    /**
     * Obtiene todos los empleados activos.
     *
     * @return Lista de empleados activos
     */
    public List<Empleado> obtenerEmpleadosActivos() {
        return empleadoRepository.findByFechaBajaIsNull();
    }

    /**
     * Valida los datos de un empleado.
     *
     * @param empleado El empleado a validar
     * @return true si los datos son válidos, false de lo contrario
     */
    public boolean validarEmpleado(Empleado empleado) {
        // Validar el NIF
        if (!empleado.getNif().matches("\\d{8}[A-Za-z]")) {
            return false;
        }

        // Validar nombre y apellidos
        if (!empleado.getNombre().matches("[A-Za-zñÑáéíóúÁÉÍÓÚüÜ\\s]+") ||
                !empleado.getPrimerApellido().matches("[A-Za-zñÑáéíóúÁÉÍÓÚüÜ\\s]+") ||
                !empleado.getSegundoApellido().matches("[A-Za-zñÑáéíóúÁÉÍÓÚüÜ\\s]+")) {
            return false;
        }

        // Validar números de teléfono
        if ((empleado.getTelefono1() != null && !empleado.getTelefono1().isEmpty() && empleado.getTelefono1().matches("\\d{9}")) ||
                (empleado.getTelefono2() != null && !empleado.getTelefono2().isEmpty() && empleado.getTelefono2().matches("\\d{9}"))) {
            return true; // Si al menos uno de los teléfonos es válido, devuelve true
        } else {
            return false; // Si ninguno de los teléfonos es válido, devuelve false
        }
    }

    /**
     * Guarda un nuevo empleado en la base de datos.
     *
     * @param empleado El empleado a guardar
     * @return El empleado guardado
     * @throws IllegalArgumentException Si los datos del empleado no son válidos
     */
    public Empleado guardarEmpleado(Empleado empleado) {
        if (validarEmpleado(empleado)) {
            return empleadoRepository.save(empleado);
        } else {
            throw new IllegalArgumentException("Los datos del empleado no son válidos");
        }
    }

    /**
     * Da de baja a un empleado.
     *
     * @param empleadoId El ID del empleado a dar de baja
     * @return true si la operación fue exitosa, false de lo contrario
     */
    public boolean darDeBajaEmpleado(int empleadoId) {
        Empleado empleado = empleadoRepository.findById(empleadoId).orElse(null);
        if (empleado == null) {
            // Empleado no encontrado
            return false;
        }
        // Actualizar la fecha de baja del empleado
        empleado.setFechaBaja(LocalDate.now());
        empleadoRepository.save(empleado);
        return true;
    }
}
