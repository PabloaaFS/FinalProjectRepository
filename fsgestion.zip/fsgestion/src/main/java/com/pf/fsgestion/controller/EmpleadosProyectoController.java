package com.pf.fsgestion.controller;

import com.pf.fsgestion.entity.EmpleadosProyecto;
import com.pf.fsgestion.repository.EmpleadosProyectoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/empleados-proyecto")
public class EmpleadosProyectoController {

    @Autowired
    private EmpleadosProyectoRepository empleadosProyectoRepository;

    @GetMapping
    public ResponseEntity<List<EmpleadosProyecto>> obtenerTodosEmpleadosProyecto() {
        List<EmpleadosProyecto> empleadosProyecto = empleadosProyectoRepository.findAll();
        return new ResponseEntity<>(empleadosProyecto, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<EmpleadosProyecto> agregarEmpleadoProyecto(@RequestBody EmpleadosProyecto empleadoProyecto) {
        EmpleadosProyecto nuevoEmpleadoProyecto = empleadosProyectoRepository.save(empleadoProyecto);
        return new ResponseEntity<>(nuevoEmpleadoProyecto, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEmpleadoProyecto(@PathVariable int id) {
        empleadosProyectoRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

