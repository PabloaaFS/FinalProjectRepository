package com.pf.fsgestion.repository;

import com.pf.fsgestion.entity.EmpleadosProyecto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpleadosProyectoRepository extends JpaRepository<EmpleadosProyecto, Integer> {
}

