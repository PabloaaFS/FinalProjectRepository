package com.pf.fsgestion.controller;

import com.pf.fsgestion.entity.Proyecto;
import com.pf.fsgestion.service.ProyectoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador para manejar las operaciones relacionadas con los proyectos.
 */
@RestController
@RequestMapping("/proyectos")
public class ProyectoController {

    @Autowired
    private ProyectoService proyectoService;

    /**
     * Obtiene una lista de todos los proyectos.
     * @return lista de proyectos
     */
    @GetMapping("/mostrarproyectos")
    public List<Proyecto> obtenerTodosLosProyectos() {
        return proyectoService.obtenerTodosLosProyectos();
    }

    /**
     * Maneja la solicitud de creación de un nuevo proyecto.
     * @param proyecto el objeto Proyecto que se va a crear
     * @return ResponseEntity con el resultado de la operación
     */
    @PostMapping("/crear")
    public ResponseEntity<?> crearProyecto(@RequestBody Proyecto proyecto) {
        try {
            if (!proyectoService.validarProyecto(proyecto)) {
                return ResponseEntity.badRequest().body("Los datos del proyecto son inválidos");
            }

            Proyecto nuevoProyecto = proyectoService.guardarProyecto(proyecto);
            return ResponseEntity.ok(nuevoProyecto);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    /**
     * Maneja la solicitud de eliminación de un proyecto por su ID.
     * @param proyectoId el ID del proyecto a eliminar
     * @return ResponseEntity con el resultado de la operación
     */
    @DeleteMapping("/eliminar/{id}")
    public ResponseEntity<?> eliminarProyecto(@PathVariable("id") int proyectoId) {
        boolean eliminacionExitosa = proyectoService.eliminarProyecto(proyectoId);
        if (eliminacionExitosa) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
