package com.pf.fsgestion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FsgestionApplication {

	public static void main(String[] args) {
		SpringApplication.run(FsgestionApplication.class, args);
	}

}
