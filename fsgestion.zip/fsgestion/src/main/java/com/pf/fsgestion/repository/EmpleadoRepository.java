package com.pf.fsgestion.repository;

import com.pf.fsgestion.entity.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repositorio para la entidad Empleado, que proporciona métodos de acceso a la base de datos.
 */
@Repository
public interface EmpleadoRepository extends JpaRepository<Empleado, Integer> {

    /**
     * Obtiene una lista de empleados cuya fecha de baja es nula, es decir, empleados activos.
     * @return Una lista de empleados activos.
     */
    List<Empleado> findByFechaBajaIsNull();
}
