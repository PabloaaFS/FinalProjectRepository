package com.pf.fsgestion.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 * Clase que representa la entidad Proyecto en la base de datos.
 */
@Entity
@Table(name = "PR_PROYECTOS")
public class Proyecto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_PROYECTO")
    private int id;

    @Column(name = "TX_DESCRIPCIÓN")
    private String descripcion;

    @Column(name = "F_INICIO")
    private LocalDate fechaInicio;

    @Column(name = "F_FIN")
    private LocalDate fechaFin;

    @Column(name = "F_BAJA")
    private LocalDate fechaBaja;

    @Column(name = "TX_LUGAR")
    private String lugar;

    @Column(name = "TX_OBSERVACIONES")
    private String observaciones;

    /**
     * Constructor vacío requerido por Hibernate.
     */
    public Proyecto() {
        // Constructor sin argumentos necesario para Hibernate
    }

    /**
     * Constructor de la clase Proyecto.
     * @param id Identificador único del proyecto.
     * @param descripcion Descripción del proyecto.
     * @param fechaInicio Fecha de inicio del proyecto.
     * @param fechaFin Fecha de finalización del proyecto.
     * @param fechaBaja Fecha de baja del proyecto.
     * @param lugar Lugar donde se realiza el proyecto.
     * @param observaciones Observaciones adicionales sobre el proyecto.
     */
    public Proyecto(int id, String descripcion, LocalDate fechaInicio, LocalDate fechaFin, LocalDate fechaBaja, String lugar, String observaciones) {
        this.id = id;
        this.descripcion = descripcion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.fechaBaja = fechaBaja;
        this.lugar = lugar;
        this.observaciones = observaciones;
    }

    // Métodos getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    public LocalDate getFechaBaja() {
        return fechaBaja;
    }

    public void setFechaBaja(LocalDate fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }
}

