package com.pf.fsgestion.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

/**
 * Clase que representa la entidad Empleado en la base de datos.
 */
@Entity
@Table(name = "EM_EMPLEADOS")
public class Empleado {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_EMPLEADO")
    private int id;

    @Column(name = "TX_NIF")
    private String nif;

    @Column(name = "TX_NOMBRE")
    private String nombre;

    @Column(name = "TX_APELLIDO1")
    private String primerApellido;

    @Column(name = "TX_APELLIDO2")
    private String segundoApellido;

    @Column(name = "F_NACIMIENTO")
    private LocalDate fechaNacimiento;

    @Column(name = "F_ALTA")
    private LocalDate fechaAlta;

    @Column(name = "F_BAJA")
    private LocalDate fechaBaja;

    @Column(name = "N_TELEFONO1")
    private String telefono1;

    @Column(name = "N_TELEFONO2")
    private String telefono2;

    @Column(name = "TX_EMAIL")
    private String email;

    @Column(name = "CX_EDOCIVIL")
    private String estadoCivil;

    @Column(name = "B_SERVMILITAR")
    private String servicioMilitar;

    /**
     * Constructor sin argumentos necesario para Hibernate.
     */
    public Empleado() {
    }

    /**
     * Constructor con argumentos para inicializar todos los campos de la entidad Empleado.
     * @param id el ID del empleado
     * @param nif el NIF del empleado
     * @param nombre el nombre del empleado
     * @param primerApellido el primer apellido del empleado
     * @param segundoApellido el segundo apellido del empleado
     * @param fechaNacimiento la fecha de nacimiento del empleado
     * @param fechaAlta la fecha de alta del empleado
     * @param fechaBaja la fecha de baja del empleado
     * @param telefono1 el primer número de teléfono del empleado
     * @param telefono2 el segundo número de teléfono del empleado
     * @param email el correo electrónico del empleado
     * @param estadoCivil el estado civil del empleado
     * @param servicioMilitar el servicio militar del empleado
     */
    public Empleado(int id, String nif, String nombre, String primerApellido, String segundoApellido, LocalDate fechaNacimiento,
                    LocalDate fechaAlta, LocalDate fechaBaja, String telefono1, String telefono2, String email, String estadoCivil,
                    String servicioMilitar) {
        this.id = id;
        this.nif = nif;
        this.nombre = nombre;
        this.primerApellido = primerApellido;
        this.segundoApellido = segundoApellido;
        this.fechaNacimiento = fechaNacimiento;
        this.fechaAlta = fechaAlta;
        this.fechaBaja = fechaBaja;
        this.telefono1 = telefono1;
        this.telefono2 = telefono2;
        this.email = email;
        this.estadoCivil = estadoCivil;
        this.servicioMilitar = servicioMilitar;
    }

    // Getters y setters para todos los atributos de la entidad Empleado
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public String getSegundoApellido() {
        return segundoApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public LocalDate getFechaBaja() {
        return fechaBaja;
    }

    public void setFechaBaja(LocalDate fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

    public String getTelefono1() {
        return telefono1;
    }

    public void setTelefono1(String telefono1) {
        this.telefono1 = telefono1;
    }

    public String getTelefono2() {
        return telefono2;
    }

    public void setTelefono2(String telefono2) {
        this.telefono2 = telefono2;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getServicioMilitar() {
        return servicioMilitar;
    }

    public void setServicioMilitar(String servicioMilitar) {
        this.servicioMilitar = servicioMilitar;
    }
}
