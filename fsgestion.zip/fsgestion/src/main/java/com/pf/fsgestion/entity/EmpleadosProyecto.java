package com.pf.fsgestion.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name = "pr_empleados_proyecto")
public class EmpleadosProyecto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private int id;

    @Column(name = "ID_PROYECTO")
    private int idProyecto;

    @Column(name = "ID_EMPLEADO")
    private int idEmpleado;

    @Column(name = "F_ALTA")
    private LocalDate fechaAlta;

    // Constructor, getters y setters

    public EmpleadosProyecto() {
        // Constructor sin argumentos necesario para Hibernate
    }

    public EmpleadosProyecto(int idProyecto, int idEmpleado, LocalDate fechaAlta) {
        this.idProyecto = idProyecto;
        this.idEmpleado = idEmpleado;
        this.fechaAlta = fechaAlta;
    }

    public int getIdProyecto() {
        return idProyecto;
    }

    public void setIdProyecto(int idProyecto) {
        this.idProyecto = idProyecto;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }
}

