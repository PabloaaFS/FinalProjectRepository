package com.pf.fsgestion.repository;

import com.pf.fsgestion.entity.Empleado;
import com.pf.fsgestion.entity.Proyecto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repositorio para la entidad Proyecto, que proporciona métodos de acceso a la base de datos.
 */
@Repository
public interface ProyectoRepository extends JpaRepository<Proyecto, Integer> {
}

