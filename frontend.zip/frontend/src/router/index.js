import Vue from 'vue';
import VueRouter from 'vue-router';
import ConsultaEmpleados from '../views/ConsultaEmpleados.vue';
import AltaEmpleado from '../views/AltaEmpleado.vue';
import ConsultaProyectos from '../views/ConsultaProyectos.vue';
import AltaProyecto from '../views/AltaProyecto.vue';
import EmpleadosProyecto from '@/views/EmpleadosProyecto.vue';

Vue.use(VueRouter);

// Configuración de las rutas de la aplicación
const routes = [
  {
    path: '/', // Ruta de inicio
    redirect: '/consulta-empleados', // Redirigir a la vista de consulta de empleados por defecto
  },
  {
    path: '/consulta-empleados', // Ruta para consultar empleados
    name: 'ConsultaEmpleados', // Nombre de la ruta
    component: ConsultaEmpleados, // Componente asociado a la ruta
  },
  {
    path: '/alta-empleado', // Ruta para dar de alta a un empleado
    name: 'AltaEmpleado', // Nombre de la ruta
    component: AltaEmpleado, // Componente asociado a la ruta
  },
  {
    path: '/consulta-proyectos', // Ruta para consultar proyectos
    name: 'ConsultaProyectos', // Nombre de la ruta
    component: ConsultaProyectos, // Componente asociado a la ruta
  },
  {
    path: '/alta-proyecto', // Ruta para dar de alta a un proyecto
    name: 'AltaProyecto', // Nombre de la ruta
    component: AltaProyecto, // Componente asociado a la ruta
  },
  {
    path: '/empleados-proyecto', // Ruta para asignar empleados a proyectos
    name: 'EmpleadosProyecto', // Nombre de la ruta
    component: EmpleadosProyecto, // Componente asociado a la ruta
  },
];

// Creación del enrutador de Vue
const router = new VueRouter({
  routes, // Configuración de las rutas
});

export default router; // Exportar el enrutador para que pueda ser utilizado en la aplicación
