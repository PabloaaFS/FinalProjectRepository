import Vue from 'vue';
import Vuex from 'vuex';
import axios from 'axios'; // Importa axios para realizar solicitudes HTTP

// Almacén centralizado para todos los componentes de una aplicación, con reglas que garantizan
// que el estado se puede cambiar de manera predecible.
Vue.use(Vuex);

export default new Vuex.Store({
  // Objeto que contiene el estado centralizado de la aplicación. 
  // Aquí se definen los estados empleados y proyectos para almacenar las listas de empleados y proyectos respectivamente.
  state: {
    empleados: [],
    proyectos: [], 
  },
  getters: {
    // Getters para acceder y transformar los estados si es necesario
  },
  mutations: {
    // Mutations para modificar el estado de manera síncrona
    SET_EMPLEADOS(state, empleados) {
      state.empleados = empleados;
    },
    AGREGAR_EMPLEADO(state, nuevoEmpleado) {
      state.empleados.push(nuevoEmpleado);
    },
    DAR_DE_BAJA_EMPLEADO(state, empleadoId) {
      state.empleados = state.empleados.filter(empleado => empleado.id !== empleadoId);
    },
    SET_PROYECTOS(state, proyectos) {
      state.proyectos = proyectos;
    },
    AGREGAR_PROYECTO(state, nuevoProyecto) {
      state.proyectos.push(nuevoProyecto);
    },
    DAR_DE_BAJA_PROYECTO(state, proyectoId) {
      state.proyectos = state.proyectos.filter(proyecto => proyecto.id !== proyectoId);
    },
  },
  actions: {
    // Acciones para realizar operaciones asíncronas y modificar el estado usando mutations
    async cargarEmpleados({ commit }) {
      try {
        const response = await axios.get('/empleados/activos');
        commit('SET_EMPLEADOS', response.data);
      } catch (error) {
        console.error('Error al cargar los empleados:', error);
      }
    },
    async agregarEmpleado({ commit }, nuevoEmpleado) {
      try {
        const response = await axios.post('/empleados/alta', nuevoEmpleado);
        commit('AGREGAR_EMPLEADO', response.data);
      } catch (error) {
        console.error('Error al agregar el empleado:', error);
      }
    },
    async darDeBajaEmpleado({ commit }, empleadoId) {
      try {
        await axios.delete(`/empleados/baja/${empleadoId}`);
        commit('DAR_DE_BAJA_EMPLEADO', empleadoId);
      } catch (error) {
        console.error('Error al dar de baja el empleado:', error);
      }
    },
    async cargarProyectos({ commit }) {
      try {
        const response = await axios.get('/proyectos/mostrarproyectos');
        commit('SET_PROYECTOS', response.data);
      } catch (error) {
        console.error('Error al cargar los proyectos:', error);
      }
    },
    async agregarProyecto({ commit }, nuevoProyecto) {
      try {
        const response = await axios.post('/proyectos/crear', nuevoProyecto);
        commit('AGREGAR_PROYECTO', response.data);
      } catch (error) {
        console.error('Error al agregar el proyecto:', error);
      }
    },
    async darDeBajaProyecto({ commit }, proyectoId) {
      try {
        await axios.delete(`/proyectos/eliminar/${proyectoId}`);
        commit('DAR_DE_BAJA_PROYECTO', proyectoId);
      } catch (error) {
        console.error('Error al dar de baja el proyecto:', error);
      }
    },
  },
  modules: {},
});
