// Importaciones de módulos y configuraciones
import Vue from 'vue'; // Importa la librería Vue.js
import App from './App.vue'; // Importa el componente principal de la aplicación
import router from './router'; // Importa el enrutador de la aplicación
import store from './store'; // Importa el almacenamiento de Vuex para la gestión del estado de la aplicación
import vuetify from './plugins/vuetify'; // Importa la configuración de Vuetify

// Configuración de Vue.js
Vue.config.productionTip = false; // Configura Vue para suprimir los mensajes de producción en la consola

// Creación de una nueva instancia de Vue
new Vue({
  router, // Asigna el enrutador importado a la instancia de Vue
  store, // Asigna el almacenamiento Vuex importado a la instancia de Vue
  vuetify, // Asigna la configuración de Vuetify importada a la instancia de Vue
  render: h => h(App) // Define la función de renderizado del componente principal de la aplicación
}).$mount('#app'); // Monta la instancia de Vue en el elemento con el ID "app" en el DOM
