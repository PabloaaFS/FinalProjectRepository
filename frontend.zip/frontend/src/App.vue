<template>
  <!-- Componente raíz de la aplicación utilizando v-app de Vuetify -->
  <v-app>
    <!-- Barra de la aplicación -->
    <v-app-bar
      app
      color="primary"
      dark
    >
      <!-- Contenedor flexible para alinear elementos horizontalmente -->
      <div class="d-flex align-center">
        <!-- Imagen del logo de Vuetify -->
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="https://cdn.vuetifyjs.com/images/logos/vuetify-logo-dark.png"
          transition="scale-transition"
          width="40"
        />

        <!-- Texto del nombre de la aplicación -->

      </div>

      <!-- Espaciador flexible para alinear elementos en la barra -->
      <v-spacer></v-spacer>

      <!-- Botón para promocionar Future Space -->
      <v-btn
        href="http://futurespace.es"
        target="_blank"
        text
      >
        <span class="mr-2">Promoted by Future Space</span>
      </v-btn>
    </v-app-bar>

    <!-- Contenido principal de la aplicación -->
    <v-main>
      <!-- Vista del enrutador, se mostrará el componente correspondiente según la ruta -->
      <router-view/>
    </v-main>
  </v-app>
</template>

<script>
// Exporta el componente principal de la aplicación
export default {
  // Nombre del componente
  name: 'App',

  // Datos del componente (en este caso, no se define nada)
  data: () => ({
    //
  }),
};
</script>
