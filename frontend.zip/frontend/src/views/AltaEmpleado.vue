<template>
  <!-- Contenedor principal utilizando el sistema de diseño de Material Design de Vuetify -->
  <v-container>
    <!-- Fila principal -->
    <v-row>
      <!-- Columna principal -->
      <v-col cols="12">
        <!-- Tarjeta para el formulario de alta de empleado -->
        <v-card>
          <!-- Título de la tarjeta -->
          <v-card-title>Alta de Empleado</v-card-title>
          <v-card-text>
            <!-- Formulario para agregar un nuevo empleado -->
            <v-form ref="form" @submit.prevent="agregarEmpleado">
              <!-- Contenedor principal del formulario -->
              <v-container>
                <!-- Fila para los campos del formulario -->
                <v-row>
                  <!-- Columna para el campo NIF -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoEmpleado.nif" label="NIF" required></v-text-field>
                  </v-col>
                  <!-- Columna para el campo Nombre -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoEmpleado.nombre" label="Nombre" required></v-text-field>
                  </v-col>
                  <!-- Columna para el campo Primer Apellido -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoEmpleado.primerApellido" label="Primer Apellido" required></v-text-field>
                  </v-col>
                  <!-- Columna para el campo Segundo Apellido -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoEmpleado.segundoApellido" label="Segundo Apellido" required></v-text-field>
                  </v-col>
                  <!-- Columna para el campo Fecha de Nacimiento -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoEmpleado.fechaNacimiento" label="Fecha de Nacimiento" @click="showDatePicker('fechaNacimiento')" required></v-text-field>
                    <!-- Selector de fecha de nacimiento -->
                    <v-date-picker v-model="nuevoEmpleado.fechaNacimiento" v-if="showDatePickerFor === 'fechaNacimiento'" @input="showDatePickerFor = ''"></v-date-picker>
                  </v-col>
                  <!-- Columna para el campo Fecha de Alta -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoEmpleado.fechaAlta" label="Fecha de Alta" @click="showDatePicker('fechaAlta')" required></v-text-field>
                    <!-- Selector de fecha de alta -->
                    <v-date-picker v-model="nuevoEmpleado.fechaAlta" v-if="showDatePickerFor === 'fechaAlta'" @input="showDatePickerFor = ''"></v-date-picker>
                  </v-col>
                  <!-- Columna para el campo Primer Teléfono -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoEmpleado.telefono1" label="Primer Teléfono" required></v-text-field>
                  </v-col>
                  <!-- Columna para el campo Segundo Teléfono -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoEmpleado.telefono2" label="Segundo Teléfono"></v-text-field>
                  </v-col>
                  <!-- Columna para el campo Email -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoEmpleado.email" label="Email" required></v-text-field>
                  </v-col>
                  <!-- Columna para el campo Estado Civil -->
                  <v-col cols="6">
                    <v-select v-model="nuevoEmpleado.estadoCivil" :items="['S', 'C']" label="Estado Civil" required></v-select>
                  </v-col>
                  <!-- Columna para el campo Servicio Militar -->
                  <v-col cols="6">
                    <v-select v-model="nuevoEmpleado.servicioMilitar" :items="['S', 'N']" label="Servicio Militar" required></v-select>
                  </v-col>
                </v-row>
              </v-container>
              <!-- Botones de acción -->
              <v-btn color="primary" type="submit">Aceptar</v-btn>
              <v-btn @click="cancelar">Cancelar</v-btn>
            </v-form>
            <!-- Alerta para mostrar errores -->
            <v-alert v-if="error" type="error" dismissible>
              {{ error }}
            </v-alert>
            <!-- Alerta para mostrar éxito -->
            <v-alert v-if="success" type="success" dismissible>
              {{ success }}
            </v-alert>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      // Datos del nuevo empleado
      nuevoEmpleado: {
        nif: '',
        nombre: '',
        primerApellido: '',
        segundoApellido: '',
        fechaNacimiento: '',
        fechaAlta: '',
        telefono1: '',
        telefono2: '',
        email: '',
        estadoCivil: '',
        servicioMilitar: '',
      },
      // Variable para manejar errores
      error: '',
      // Variable para manejar éxito
      success: '',
      // Variable para controlar qué campo de fecha mostrar en el selector
      showDatePickerFor: '',
    };
  },
  methods: {
    // Método para mostrar el selector de fecha
    showDatePicker(field) {
      this.showDatePickerFor = field;
    },
    // Método para agregar empleado
    agregarEmpleado() {
      console.log('Datos del nuevo empleado:', this.nuevoEmpleado); // Depuración: Imprime los datos del nuevo empleado
      if (!this.nuevoEmpleado.nif || !this.nuevoEmpleado.nombre || !this.nuevoEmpleado.primerApellido || !this.nuevoEmpleado.segundoApellido || !this.nuevoEmpleado.fechaNacimiento || !this.nuevoEmpleado.fechaAlta || !this.nuevoEmpleado.telefono1 || !this.nuevoEmpleado.telefono2 || !this.nuevoEmpleado.email || !this.nuevoEmpleado.estadoCivil || !this.nuevoEmpleado.servicioMilitar) {
        // Validación: Se asegura de que todos los campos obligatorios estén completos
        this.$vuetify.dialog.alert('Es obligatorio introducir todos los datos para dar de alta un nuevo empleado');
      } else {
        // Envía una solicitud HTTP para agregar el empleado
        axios.post('http://localhost:8081/empleados/alta', this.nuevoEmpleado)
          .then(() => {
            // Si se agrega correctamente, muestra un mensaje de éxito y redirige a la página de consulta de empleados
            this.success = 'Empleado dado de alta exitosamente.';
            if (this.$route.path !== '/consulta-empleados') {
              this.$router.push('/consulta-empleados');
            }
            // Muestra un diálogo de éxito
            this.$vuetify.dialog.alert('Empleado registrado con éxito');
          })
          .catch(error => {
            // Si hay un error, muestra un mensaje de error
            console.error('Error al agregar empleado:', error);
            this.error = 'Error al agregar empleado: ' + error.message;
          });
      }
    },
    // Método para limpiar formulario
    limpiarFormulario() {
      this.nuevoEmpleado = {
        nif: '',
        nombre: '',
        primerApellido: '',
        segundoApellido: '',
        fechaNacimiento: '',
        fechaAlta: '',
        telefono1: '',
        telefono2: '',
        email: '',
        estadoCivil: '',
        servicioMilitar: '',
      };
    },
    // Método para cancelar
    cancelar() {
      console.log('Alta de empleado cancelada');
      // Redirige a la página de consulta de empleados
      this.$router.push('/consulta-empleados');
    },
  },
};
</script>