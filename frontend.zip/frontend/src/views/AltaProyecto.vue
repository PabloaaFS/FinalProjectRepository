<template>
  <!-- Contenedor principal utilizando el sistema de diseño de Material Design de Vuetify -->
  <v-container>
    <!-- Fila principal -->
    <v-row>
      <!-- Columna principal -->
      <v-col cols="12">
        <!-- Tarjeta para el formulario de alta de proyecto -->
        <v-card>
          <!-- Título de la tarjeta -->
          <v-card-title>Alta de Proyecto</v-card-title>
          <v-card-text>
            <!-- Formulario para agregar un nuevo proyecto -->
            <v-form ref="form" @submit.prevent="agregarProyecto">
              <!-- Contenedor principal del formulario -->
              <v-container>
                <!-- Fila para los campos del formulario -->
                <v-row>
                  <!-- Columna para el campo Descripción -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoProyecto.descripcion" label="Descripción" required></v-text-field>
                  </v-col>
                  <!-- Columna para el campo Fecha de inicio -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoProyecto.fechaInicio" label="Fecha de inicio"
                      @click="showDatePicker('fechaInicio')" required></v-text-field>
                    <!-- Selector de fecha de inicio -->
                    <v-date-picker v-model="nuevoProyecto.fechaInicio" v-if="showDatePickerFor === 'fechaInicio'"
                      @input="showDatePickerFor = ''"></v-date-picker>
                  </v-col>
                  <!-- Columna para el campo Fecha de finalización -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoProyecto.fechaFin" label="Fecha de finalización"
                      @click="showDatePicker('fechaFin')" required></v-text-field>
                    <!-- Selector de fecha de finalización -->
                    <v-date-picker v-model="nuevoProyecto.fechaFin" v-if="showDatePickerFor === 'fechaFin'"
                      @input="showDatePickerFor = ''"></v-date-picker>
                  </v-col>
                  <!-- Columna para el campo Lugar -->
                  <v-col cols="6">
                    <v-text-field v-model="nuevoProyecto.lugar" label="Lugar" required></v-text-field>
                  </v-col>
                  <!-- Columna para el campo Observaciones -->
                  <v-col cols="12">
                    <v-text-field v-model="nuevoProyecto.observaciones" label="Observaciones"></v-text-field>
                  </v-col>
                </v-row>
              </v-container>
              <!-- Botones de acción -->
              <v-btn color="primary" type="submit">Aceptar</v-btn>
              <v-btn @click="cancelar">Cancelar</v-btn>
            </v-form>
            <!-- Alerta para mostrar errores -->
            <v-alert v-if="error" type="error" dismissible>
              {{ error }}
            </v-alert>
            <!-- Alerta para mostrar éxito -->
            <v-alert v-if="success" type="success" dismissible>
              {{ success }}
            </v-alert>
          </v-card-text>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      // Datos del nuevo proyecto
      nuevoProyecto: {
        descripcion: '',
        fechaInicio: null,
        fechaFin: null,
        lugar: '',
        observaciones: '',
      },
      // Variable para manejar errores
      error: '',
      // Variable para manejar éxito
      success: '',
      // Variable para controlar qué campo de fecha mostrar en el selector
      showDatePickerFor: '',
    };
  },
  methods: {
    // Método para mostrar el selector de fecha
    showDatePicker(field) {
      this.showDatePickerFor = field;
    },
    // Método para agregar proyecto
    agregarProyecto() {
      // Validación: Se asegura de que todos los campos obligatorios estén completos
      if (!this.nuevoProyecto.descripcion || !this.nuevoProyecto.fechaInicio || !this.nuevoProyecto.fechaFin || !this.nuevoProyecto.lugar) {
        this.$vuetify.dialog.alert('Es obligatorio introducir todos los datos para dar de alta un nuevo proyecto');
      } else {
        // Envía una solicitud HTTP para agregar el proyecto
        axios.post('http://localhost:8081/proyectos/crear', this.nuevoProyecto)
          .then(() => {
            // Si se agrega correctamente, muestra un mensaje de éxito y redirige a la página de consulta de proyectos
            this.success = 'Proyecto creado exitosamente.';
            this.$router.push('/consulta-proyectos');
          })
          .catch(error => {
            // Si hay un error, muestra un mensaje de error
            console.error('Error al agregar proyecto:', error);
            this.error = 'Error al agregar proyecto: ' + error.message;
          });
      }
    },
    // Método para cancelar
    cancelar() {
      // Redirige a la página de consulta de proyectos
      this.$router.push('/consulta-proyectos');
    },
  },
};
</script>
