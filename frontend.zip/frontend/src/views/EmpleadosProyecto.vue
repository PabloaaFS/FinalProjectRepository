<template>
    <v-container>
      <!-- Menú lateral -->
      <v-navigation-drawer app>
        <v-list dense>
          <v-list-item>
            <v-list-item-title>FUTURE SPACE GESTIÓN</v-list-item-title>
          </v-list-item>
          <v-list-item link to="/consulta-empleados">
            <v-list-item-title>Consulta Empleados</v-list-item-title>
          </v-list-item>
          <v-list-item link to="/consulta-proyectos">
            <v-list-item-title>Consulta Proyectos</v-list-item-title>
          </v-list-item>
          <v-list-item link to="/empleados-proyecto">
            <v-list-item-title>Asignacion Empleados a Proyectos</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-navigation-drawer>

      <!-- Selector de proyecto -->
      <v-row>
        <v-col cols="6">
          <v-select v-model="selectedProject" :items="projects" label="Proyecto" outlined @change="fetchEmployees"></v-select>
        </v-col>
      </v-row>
  
      <!-- Lista de empleados -->
      <v-row>
        <v-col cols="12">
          <v-checkbox v-for="employee in employees" :key="employee.id" v-model="employee.checked" :label="`${employee.nombre} ${employee.apellido}`"></v-checkbox>
        </v-col>
      </v-row>
  
      <!-- Botón de asignar -->
      <v-row>
        <v-col cols="12">
          <v-btn color="primary" @click="assignEmployees">Asignar Empleados</v-btn>
        </v-col>
      </v-row>
    </v-container>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        selectedProject: null,
        projects: [], // Lista de proyectos disponibles
        employees: [], // Lista de empleados disponibles
      };
    },
    mounted() {
      this.fetchProjects();
    },
    methods: {
      fetchProjects() {
        // Lógica para obtener la lista de proyectos disponibles
        axios.get('http://localhost:8081/proyectos/disponibles')
          .then(response => {
            this.projects = response.data;
          })
          .catch(error => {
            console.error('Error al obtener la lista de proyectos:', error);
          });
      },
      fetchEmployees() {
        if (this.selectedProject) {
          // Lógica para obtener la lista de empleados asociados al proyecto seleccionado
          axios.get(`http://localhost:8081/empleados/proyecto/${this.selectedProject.id}`)
            .then(response => {
              this.employees = response.data;
            })
            .catch(error => {
              console.error('Error al obtener la lista de empleados:', error);
            });
        }
      },
      assignEmployees() {
        const selectedEmployees = this.employees.filter(employee => employee.checked);
        // Lógica para asignar empleados al proyecto seleccionado
        axios.post(`http://localhost:8081/proyectos/${this.selectedProject.id}/asignar-empleados`, selectedEmployees)
          .then(() => {
            // Mensaje de éxito o redirección si es necesario
          })
          .catch(error => {
            console.error('Error al asignar empleados al proyecto:', error);
          });
      },
    },
  };
  </script>
  