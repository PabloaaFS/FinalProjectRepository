<template>
  <!-- Fila principal -->
  <v-row>
    <!-- Menú lateral -->
    <v-list dense>
      <v-list-item>
        <v-list-item-title>FUTURE SPACE GESTIÓN</v-list-item-title>
      </v-list-item>
      <v-list-item link to="/consulta-empleados">
        <v-list-item-title>Consulta Empleados</v-list-item-title>
      </v-list-item>
      <v-list-item link to="/consulta-proyectos">
        <v-list-item-title>Consulta Proyectos</v-list-item-title>
      </v-list-item>
      <v-list-item link to="/empleados-proyecto">
        <v-list-item-title>Asignación Empleados a Proyectos</v-list-item-title>
      </v-list-item>
    </v-list>

    <!-- Contenido principal -->
    <v-col cols="12">
      <!-- Encabezado principal -->
      <h1>Consulta de Empleados</h1>
      <!-- Tabla de datos -->
      <v-data-table :headers="headers" :items="empleados">
        <template v-slot:item.actions="{ item }">
          <v-icon small @click="darDeBajaEmpleado(item.id)">
            mdi-delete
          </v-icon>
        </template>

      </v-data-table>
      <!-- Botón para redirigir a la página de alta de empleado -->
      <v-btn color="primary" @click="irAAltaEmpleado">Alta Empleado</v-btn>
    </v-col>
  </v-row>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      // Encabezados de la tabla
      headers: [
        { text: 'NIF', value: 'nif' },
        { text: 'Nombre', value: 'nombre' },
        { text: 'Primer Apellido', value: 'primerApellido' },
        { text: 'Segundo Apellido', value: 'segundoApellido' },
        { text: 'Fecha de Nacimiento', value: 'fechaNacimiento' },
        { text: 'Primer Teléfono', value: 'telefono1' },
        { text: 'Segundo Teléfono', value: 'telefono2' },
        { text: 'Email', value: 'email' },
        { text: 'Estado Civil', value: 'estadoCivil' },
        { text: 'Servicio Militar', value: 'servicioMilitar' },
        { text: 'Dar de Baja', value: 'actions', sortable: false },
      ],
      // Datos de empleados
      empleados: [],
    };
  },
  mounted() {
    // Método que se ejecuta para llenar el array con los empleados
    this.cargarEmpleados();
  },
  methods: {
    // Método para cargar los empleados desde la API
    cargarEmpleados() {
      axios.get('http://localhost:8081/empleados/activos')
        .then(response => {
          this.empleados = response.data;
        })
        .catch(error => {
          console.error('Error al cargar empleados:', error);
        });
    },
    // Método para dar de baja un empleado
    darDeBajaEmpleado(idEmpleado) {
      axios.delete(`http://localhost:8081/empleados/baja/${idEmpleado}`)
        .then(() => {
          // Recarga la lista de empleados después de dar de baja uno
          this.cargarEmpleados();
        })
        .catch(error => {
          console.error('Error al dar de baja al empleado:', error);
          this.error = 'Error al dar de baja al empleado:' + error.message
        });
    },
    // Método para redirigir a la página de alta de empleado
    irAAltaEmpleado() {
      this.$router.push('/alta-empleado');
    },
  },
};
</script>
