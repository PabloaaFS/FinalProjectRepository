<template>
  <!-- Fila principal -->
  <v-row>
    <!-- Menú -->
    <v-list dense>
      <v-list-item>
        <v-list-item-title>FUTURE SPACE GESTIÓN</v-list-item-title>
      </v-list-item>
      <v-list-item link to="/consulta-empleados">
        <v-list-item-title>Consulta Empleados</v-list-item-title>
      </v-list-item>
      <v-list-item link to="/consulta-proyectos">
        <v-list-item-title>Consulta Proyectos</v-list-item-title>
      </v-list-item>
      <v-list-item link to="/empleados-proyecto">
        <v-list-item-title>Asignación Empleados a Proyectos</v-list-item-title>
      </v-list-item>
    </v-list>

    <!-- Contenido principal -->
    <v-col cols="12">
      <!-- Encabezado principal -->
      <h1>Consulta de Empleados</h1>
      <!-- Tabla de datos -->
      <v-data-table :headers="headers" :items="proyectos">
        <template v-slot:item.actions="{ item }">
          <v-icon small @click="darDeBajaProyecto(item)">
            mdi-delete
          </v-icon>
        </template>
      </v-data-table>
      <!-- Botón para redirigir a la página de alta de empleado -->
      <v-btn color="primary" @click="irAAltaProyecto">Alta Proyecto</v-btn>
    </v-col>
  </v-row>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      // Encabezados de la tabla
      headers: [
        { text: 'Descripción', value: 'descripcion' },
        { text: 'Fecha de Inicio', value: 'fechaInicio' },
        { text: 'Fecha de Fin', value: 'fechaFin' },
        { text: 'Lugar', value: 'lugar' },
        { text: 'Observaciones', value: 'observaciones' },
        { text: 'Dar de Baja', value: 'actions', sortable: false }, // Para el botón de dar de baja
      ],
      // Datos de proyectos
      proyectos: [],
    };
  },
  mounted() {
    // Método que se ejecuta para llenar el array con los proyectos
    this.cargarProyectos();
  },
  methods: {
    // Método para cargar los proyectos desde la API
    cargarProyectos() {
      axios.get('http://localhost:8081/proyectos/mostrarproyectos')
        .then(response => {
          this.proyectos = response.data;
        })
        .catch(error => {
          console.error('Error al cargar proyectos:', error);
        });
    },
    // Método para dar de baja un proyecto
    darDeBajaProyecto(idProyecto) {
      axios.delete(`http://localhost:8081/empleados/baja/${idProyecto}`)
        .then(() => {
          // Recarga la lista de proyectos después de dar de baja uno
          this.cargarProyectos();
        })
        .catch(error => {
          console.error('Error al dar de baja el proyecto:', error);
          this.error = 'Error al dar de baja el proyecto:' + error.message
        });
    },
    // Método para redirigir a la página de alta de proyecto
    irAAltaProyecto() {
      this.$router.push('/alta-proyecto');
    },
  },
};
</script>
